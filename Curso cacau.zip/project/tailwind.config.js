/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        chocolate: {
          50: '#FDF7F2',
          100: '#EADDD3',
          200: '#D7C3B4',
          300: '#C4A995',
          400: '#B18F76',
          500: '#9E7557',
          600: '#8B5E3C',
          700: '#6B4423',
          800: '#4B2A0A',
          900: '#2B1000',
        },
      },
    },
  },
  plugins: [],
};