import React, { useState } from 'react';
import { Book, History, Utensils, Shield, Factory, Thermometer, Cookie, Palette, Lightbulb, Building, Play, X } from 'lucide-react';

const modules = [
  {
    id: 1,
    title: 'Introdução ao Mundo do Chocolate',
    icon: History,
    description: 'História, cadeia produtiva, mercado e legislação do chocolate no Brasil e no mundo.',
    image: 'https://images.unsplash.com/photo-1606312619070-d48b4c652a52?auto=format&fit=crop&q=80&w=2070',
    videoUrl: 'https://www.youtube.com/embed/ZWYIxJV_o6w',
    lessons: [
      'História do Chocolate',
      'Cadeia Produtiva do Cacau',
      'Mercado Atual e Tendências',
      'Legislação e Regulamentações'
    ]
  },
  {
    id: 2,
    title: 'Tipos e Diferenças entre Chocolates',
    icon: Book,
    description: 'Características, propriedades e aplicações dos diferentes tipos de chocolate.',
    image: 'https://images.unsplash.com/photo-1481391319762-47dff72954d9?auto=format&fit=crop&q=80&w=2070',
    videoUrl: 'https://www.youtube.com/embed/K0K1xJvQVvY',
    lessons: [
      'Chocolate Nobre vs Fracionado',
      'Variedades de Chocolate',
      'Composição e Propriedades',
      'Aplicações Específicas'
    ]
  },
  {
    id: 3,
    title: 'Higiene e Segurança na Produção',
    icon: Shield,
    description: 'Práticas de higiene, sanitização e segurança no trabalho.',
    image: 'https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?auto=format&fit=crop&q=80&w=2070',
    videoUrl: 'https://www.youtube.com/embed/P_JKGwkjWcM',
    lessons: [
      'Higiene Pessoal e Vestimentas',
      'Sanitização do Ambiente',
      'Soluções Sanitizantes',
      'Prevenção de Acidentes'
    ]
  },
  {
    id: 4,
    title: 'Processamento do Cacau ao Chocolate',
    icon: Factory,
    description: 'Da colheita à produção final do chocolate.',
    image: 'https://images.unsplash.com/photo-1623421536546-fa01de6a0c9f?auto=format&fit=crop&q=80&w=2070',
    videoUrl: 'https://www.youtube.com/embed/iVePwP6YZbY',
    lessons: [
      'Colheita e Fermentação',
      'Secagem e Torrefação',
      'Moagem e Prensagem',
      'Produção da Massa'
    ]
  },
  {
    id: 5,
    title: 'Técnicas de Temperagem',
    icon: Thermometer,
    description: 'Métodos e práticas para temperagem perfeita.',
    image: 'https://images.unsplash.com/photo-1511381939415-e44015466834?auto=format&fit=crop&q=80&w=2068',
    videoUrl: 'https://www.youtube.com/embed/FFX9vD_H1Uc',
    lessons: [
      'Fundamentos da Temperagem',
      'Método de Tablagem',
      'Método de Semeadura',
      'Uso de Temperadeiras'
    ]
  },
  {
    id: 6,
    title: 'Moldagem e Personalização',
    icon: Cookie,
    description: 'Técnicas de moldagem e criação de chocolates especiais.',
    image: 'https://images.unsplash.com/photo-1599599810769-bcde5a160d32?auto=format&fit=crop&q=80&w=2070',
    videoUrl: 'https://www.youtube.com/embed/Y8MT5Vc7Gto',
    lessons: [
      'Seleção de Moldes',
      'Técnicas de Moldagem',
      'Chocolates Recheados',
      'Acabamentos Especiais'
    ]
  },
  {
    id: 7,
    title: 'Decoração Artística',
    icon: Palette,
    description: 'Técnicas avançadas de decoração e acabamento.',
    image: 'https://images.unsplash.com/photo-1606312619070-d48b4c652a52?auto=format&fit=crop&q=80&w=2070',
    videoUrl: 'https://www.youtube.com/embed/zB9igRwX1Yc',
    lessons: [
      'Pinturas com Manteiga de Cacau',
      'Técnicas de Transfer',
      'Decorações 3D',
      'Acabamentos Artísticos'
    ]
  },
  {
    id: 8,
    title: 'Receitas Inovadoras',
    icon: Lightbulb,
    description: 'Desenvolvimento de produtos únicos e criativos.',
    image: 'https://images.unsplash.com/photo-1481391319762-47dff72954d9?auto=format&fit=crop&q=80&w=2070',
    videoUrl: 'https://www.youtube.com/embed/X35BvPgQyqU',
    lessons: [
      'Combinações de Sabores',
      'Ingredientes Regionais',
      'Chocolates Funcionais',
      'Tendências do Mercado'
    ]
  },
  {
    id: 9,
    title: 'Gestão e Empreendedorismo',
    icon: Building,
    description: 'Como iniciar e gerenciar seu negócio de chocolates.',
    image: 'https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?auto=format&fit=crop&q=80&w=2070',
    videoUrl: 'https://www.youtube.com/embed/K6M1_GHhx48',
    lessons: [
      'Plano de Negócios',
      'Marketing e Vendas',
      'Precificação',
      'Aspectos Legais'
    ]
  }
];

export function CourseContent() {
  const [selectedModule, setSelectedModule] = useState<number | null>(null);

  return (
    <div className="space-y-16">
      {/* Video Modal */}
      {selectedModule !== null && (
        <div className="fixed inset-0 bg-black bg-opacity-75 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-full max-w-4xl">
            <div className="p-4 border-b flex justify-between items-center">
              <h3 className="text-xl font-semibold text-gray-900">
                {modules[selectedModule].title}
              </h3>
              <button
                onClick={() => setSelectedModule(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            <div className="relative pt-[56.25%]">
              <iframe
                className="absolute inset-0 w-full h-full"
                src={modules[selectedModule].videoUrl}
                title={modules[selectedModule].title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>
            <div className="p-6">
              <h4 className="font-semibold text-lg mb-4">Conteúdo do Módulo:</h4>
              <ul className="space-y-2">
                {modules[selectedModule].lessons.map((lesson, index) => (
                  <li key={index} className="flex items-center text-gray-700">
                    <Play className="h-4 w-4 mr-2 text-chocolate-600" />
                    {lesson}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Course Modules Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {modules.map((module, index) => {
          const Icon = module.icon;
          return (
            <div key={module.id} className="bg-white rounded-lg shadow-lg overflow-hidden transform transition duration-300 hover:scale-105">
              <div className="relative h-48 overflow-hidden group">
                <img
                  src={module.image}
                  alt={module.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <button
                    onClick={() => setSelectedModule(index)}
                    className="bg-white text-chocolate-700 px-6 py-2 rounded-full flex items-center space-x-2 hover:bg-chocolate-50 transition duration-300"
                  >
                    <Play className="h-5 w-5" />
                    <span>Assistir Aula</span>
                  </button>
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <Icon className="h-6 w-6 text-chocolate-700" />
                  <h3 className="ml-2 text-xl font-semibold text-gray-900">{module.title}</h3>
                </div>
                <p className="text-gray-600 mb-4">{module.description}</p>
                <div className="space-y-2">
                  {module.lessons.map((lesson, idx) => (
                    <div key={idx} className="flex items-center text-sm text-gray-600">
                      <Play className="h-4 w-4 mr-2 text-chocolate-600" />
                      {lesson}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </section>
    </div>
  );
}