import React from 'react';
import { Check } from 'lucide-react';

const features = [
  'Acesso vitalício ao conteúdo',
  'Certificado reconhecido',
  'Suporte individual',
  'Material didático completo',
  'Comunidade exclusiva',
  'Bônus especiais',
];

export function CallToAction() {
  return (
    <div className="bg-chocolate-700">
      <div className="max-w-7xl mx-auto py-16 px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-2 lg:gap-8 lg:items-center">
          <div>
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
              Comece sua jornada hoje
            </h2>
            <p className="mt-4 text-lg text-gray-100">
              Invista no seu futuro e aprenda com os melhores profissionais do mercado.
              Garanta sua vaga com condições especiais.
            </p>
            <div className="mt-8">
              <div className="space-y-4">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-center">
                    <div className="flex-shrink-0">
                      <Check className="h-6 w-6 text-chocolate-200" />
                    </div>
                    <p className="ml-3 text-lg text-gray-100">{feature}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="mt-10 lg:mt-0">
            <div className="bg-white rounded-lg shadow-xl p-8">
              <h3 className="text-2xl font-semibold text-gray-900 mb-6">Garanta sua vaga</h3>
              <form className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                    Nome completo
                  </label>
                  <input
                    type="text"
                    id="name"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-chocolate-500 focus:ring-chocolate-500"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-chocolate-500 focus:ring-chocolate-500"
                  />
                </div>
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                    Telefone
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-chocolate-500 focus:ring-chocolate-500"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-chocolate-600 text-white py-3 px-4 rounded-md hover:bg-chocolate-700 transition duration-300"
                >
                  Quero me inscrever
                </button>
              </form>
              <p className="mt-4 text-sm text-gray-600 text-center">
                Vagas limitadas. Garanta já o seu desconto!
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}