import React from 'react';
import { GraduationCap, DollarSign, Briefcase, Heart } from 'lucide-react';

const benefits = [
  {
    title: 'Formação Completa',
    description: 'Aprenda desde os fundamentos até técnicas avançadas de produção de chocolate.',
    icon: GraduationCap,
  },
  {
    title: 'Retorno Garantido',
    description: 'Investimento que se paga com as primeiras produções comerciais.',
    icon: DollarSign,
  },
  {
    title: 'Oportunidade de Mercado',
    description: 'Mercado em crescimento com alta demanda por produtos artesanais.',
    icon: Briefcase,
  },
  {
    title: 'Faça o que Ama',
    description: 'Transforme sua paixão por chocolate em uma carreira de sucesso.',
    icon: Heart,
  },
];

export function Benefits() {
  return (
    <div className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900">Por que escolher nosso curso?</h2>
          <p className="mt-4 text-xl text-gray-600">
            Oferecemos uma formação completa para você se tornar um profissional do chocolate
          </p>
        </div>

        <div className="mt-16">
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {benefits.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <div key={index} className="text-center">
                  <div className="flex items-center justify-center h-16 w-16 rounded-full bg-chocolate-100 mx-auto">
                    <Icon className="h-8 w-8 text-chocolate-700" />
                  </div>
                  <h3 className="mt-6 text-xl font-medium text-gray-900">{benefit.title}</h3>
                  <p className="mt-2 text-base text-gray-600">{benefit.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}