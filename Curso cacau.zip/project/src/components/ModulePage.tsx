import React, { useState } from 'react';
import { Play, CheckCircle, Book, HelpCircle, ArrowLeft } from 'lucide-react';

interface Lesson {
  id: number;
  title: string;
  videoUrl: string;
  content: string;
  completed: boolean;
  quiz: {
    question: string;
    options: string[];
    correctAnswer: number;
  }[];
}

interface ModuleData {
  id: number;
  title: string;
  description: string;
  lessons: Lesson[];
}

const sampleModule: ModuleData = {
  id: 1,
  title: 'Introdução ao Mundo do Chocolate',
  description: 'História, cadeia produtiva, mercado e legislação do chocolate no Brasil e no mundo.',
  lessons: [
    {
      id: 1,
      title: 'História do Chocolate',
      videoUrl: 'https://www.youtube.com/embed/ZWYIxJV_o6w',
      content: `
        <h2>A História Fascinante do Chocolate</h2>
        <p>O chocolate tem uma história rica que remonta há mais de 4.000 anos. Os primeiros registros do uso do cacau vêm dos povos Olmecas, que habitavam a região que hoje conhecemos como México.</p>
        <h3>Origem do Cacau</h3>
        <p>O cacaueiro (Theobroma cacao) é nativo das florestas tropicais da América do Sul. Os astecas consideravam o cacau um presente dos deuses e usavam as sementes como moeda.</p>
        <h3>Chegada à Europa</h3>
        <p>O chocolate foi introduzido na Europa pelos espanhóis no século XVI, após as expedições de Hernán Cortés ao Novo Mundo. Inicialmente, era consumido apenas como bebida pela nobreza.</p>
      `,
      completed: false,
      quiz: [
        {
          question: 'Qual civilização antiga considerava o cacau um presente dos deuses?',
          options: ['Maias', 'Astecas', 'Incas', 'Olmecas'],
          correctAnswer: 1
        },
        {
          question: 'Em que século o chocolate foi introduzido na Europa?',
          options: ['XIV', 'XV', 'XVI', 'XVII'],
          correctAnswer: 2
        }
      ]
    }
  ]
};

export function ModulePage() {
  const [currentLesson, setCurrentLesson] = useState(0);
  const [showQuiz, setShowQuiz] = useState(false);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [quizSubmitted, setQuizSubmitted] = useState(false);

  const handleQuizSubmit = () => {
    setQuizSubmitted(true);
  };

  const calculateProgress = () => {
    const completedLessons = sampleModule.lessons.filter(lesson => lesson.completed).length;
    return (completedLessons / sampleModule.lessons.length) * 100;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation Header */}
        <div className="flex items-center mb-8">
          <button onClick={() => window.history.back()} className="flex items-center text-gray-600 hover:text-gray-900">
            <ArrowLeft className="h-5 w-5 mr-2" />
            Voltar aos Módulos
          </button>
        </div>

        {/* Module Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{sampleModule.title}</h1>
          <p className="text-gray-600 mb-4">{sampleModule.description}</p>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-chocolate-600 h-2 rounded-full"
              style={{ width: `${calculateProgress()}%` }}
            ></div>
          </div>
          <p className="text-sm text-gray-500 mt-2">{calculateProgress()}% completo</p>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Lesson List */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm p-4">
              <h2 className="text-xl font-semibold mb-4">Aulas do Módulo</h2>
              <div className="space-y-2">
                {sampleModule.lessons.map((lesson, index) => (
                  <button
                    key={lesson.id}
                    onClick={() => {
                      setCurrentLesson(index);
                      setShowQuiz(false);
                    }}
                    className={`w-full flex items-center p-3 rounded-lg text-left ${
                      currentLesson === index
                        ? 'bg-chocolate-50 text-chocolate-700'
                        : 'hover:bg-gray-50'
                    }`}
                  >
                    {lesson.completed ? (
                      <CheckCircle className="h-5 w-5 mr-3 text-green-500" />
                    ) : (
                      <Play className="h-5 w-5 mr-3" />
                    )}
                    <span>{lesson.title}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Lesson Content */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm">
              {!showQuiz ? (
                <>
                  {/* Video Player */}
                  <div className="relative pt-[56.25%]">
                    <iframe
                      className="absolute inset-0 w-full h-full rounded-t-lg"
                      src={sampleModule.lessons[currentLesson].videoUrl}
                      title={sampleModule.lessons[currentLesson].title}
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    ></iframe>
                  </div>

                  {/* Lesson Content */}
                  <div className="p-6">
                    <h2 className="text-2xl font-bold mb-4">
                      {sampleModule.lessons[currentLesson].title}
                    </h2>
                    <div
                      className="prose max-w-none"
                      dangerouslySetInnerHTML={{
                        __html: sampleModule.lessons[currentLesson].content,
                      }}
                    />
                    <button
                      onClick={() => setShowQuiz(true)}
                      className="mt-8 flex items-center px-4 py-2 bg-chocolate-600 text-white rounded-lg hover:bg-chocolate-700"
                    >
                      <HelpCircle className="h-5 w-5 mr-2" />
                      Iniciar Questionário
                    </button>
                  </div>
                </>
              ) : (
                /* Quiz Section */
                <div className="p-6">
                  <h2 className="text-2xl font-bold mb-6">Questionário da Aula</h2>
                  <div className="space-y-8">
                    {sampleModule.lessons[currentLesson].quiz.map((question, qIndex) => (
                      <div key={qIndex} className="border rounded-lg p-6">
                        <h3 className="text-lg font-semibold mb-4">{question.question}</h3>
                        <div className="space-y-3">
                          {question.options.map((option, oIndex) => (
                            <label
                              key={oIndex}
                              className={`flex items-center p-3 rounded-lg cursor-pointer ${
                                selectedAnswers[qIndex] === oIndex
                                  ? 'bg-chocolate-50 border border-chocolate-200'
                                  : 'hover:bg-gray-50 border border-gray-200'
                              }`}
                            >
                              <input
                                type="radio"
                                name={`question-${qIndex}`}
                                value={oIndex}
                                checked={selectedAnswers[qIndex] === oIndex}
                                onChange={() => {
                                  const newAnswers = [...selectedAnswers];
                                  newAnswers[qIndex] = oIndex;
                                  setSelectedAnswers(newAnswers);
                                }}
                                className="mr-3"
                                disabled={quizSubmitted}
                              />
                              <span>{option}</span>
                              {quizSubmitted && (
                                <span
                                  className={`ml-auto ${
                                    oIndex === question.correctAnswer
                                      ? 'text-green-500'
                                      : selectedAnswers[qIndex] === oIndex
                                      ? 'text-red-500'
                                      : ''
                                  }`}
                                >
                                  {oIndex === question.correctAnswer && '✓'}
                                  {selectedAnswers[qIndex] === oIndex &&
                                    oIndex !== question.correctAnswer &&
                                    '✗'}
                                </span>
                              )}
                            </label>
                          ))}
                        </div>
                      </div>
                    ))}
                    {!quizSubmitted ? (
                      <button
                        onClick={handleQuizSubmit}
                        className="w-full py-3 bg-chocolate-600 text-white rounded-lg hover:bg-chocolate-700"
                      >
                        Enviar Respostas
                      </button>
                    ) : (
                      <button
                        onClick={() => {
                          setShowQuiz(false);
                          setQuizSubmitted(false);
                          setSelectedAnswers([]);
                        }}
                        className="w-full py-3 bg-chocolate-600 text-white rounded-lg hover:bg-chocolate-700"
                      >
                        Voltar para a Aula
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}