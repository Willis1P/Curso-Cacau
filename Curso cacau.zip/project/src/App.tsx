import React from 'react';
import { Layout } from './components/Layout';
import { Hero } from './components/Hero';
import { Benefits } from './components/Benefits';
import { Testimonials } from './components/Testimonials';
import { CourseContent } from './components/CourseContent';
import { CallToAction } from './components/CallToAction';
import { ModulePage } from './components/ModulePage';

function App() {
  // For demonstration, we'll show the ModulePage
  // In a real app, this would be handled by routing
  const showModulePage = false;

  if (showModulePage) {
    return (
      <Layout>
        <ModulePage />
      </Layout>
    );
  }

  return (
    <Layout>
      <Hero />
      <Benefits />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Módulos do Curso</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Um programa completo e estruturado para transformar você em um especialista na arte do chocolate
          </p>
        </div>
        <CourseContent />
      </div>
      <Testimonials />
      <CallToAction />
    </Layout>
  );
}

export default App;